const app = require("express")();
const http = require("http").createServer(app);
const io = require("socket.io")(http);
const userSockets = {}; // Object to map userId to socketId
const socketToUser = {}; // Map socketId to userId

io.on("connection", (socket) => {
  console.log("A user connected: " + socket.id);

  // Save the user's socket
  socket.on("register", userId => {
    userSockets[userId] = socket.id;
    socketToUser[socket.id] = userId;
    console.log(`User ${userId} registered with socket ID ${socket.id}`);
  });

  // Handle private message
  socket.on("private message", ({ name, message, to }) => {
    console.log("\nPrivate message to: " + to);
    const senderSocketId = socket.id;
    const receiverSocketId = userSockets[to];
    if (receiverSocketId) {
      io.to(receiverSocketId).emit("message", { name, message,senderId: socket.id  });
      // Also, send the message back to the sender to display in their chat
      io.to(senderSocketId).emit("message", { name, message, senderId: socket.id });
    }
    else {
      console.log(`User ${to} not found or offline.`);
      // Handle scenarios where the user is not found or offline
      io.to(senderSocketId).emit("message", { name: "Server", message: `User ${to} not found or offline.`, senderId: "Server"  });
    }
  });
  socket.on("disconnect", () => {
    // Remove the user's socket on disconnect
    Object.keys(userSockets).forEach(userId => {
    //for (const userId in userSockets) {
      if (userSockets[userId] === socket.id) {
        delete userSockets[userId];
        delete socketToUser[socket.id];
        console.log(`User ${userId} disconnected and removed from userSockets.`);
        //break;
      }
    });
  });
});

http.listen(4000, function () {
  console.log("listening on port 4000");
});
