<?php

// Headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Database Configuration
$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

// SQL query to fetch professor details
$query = "
    SELECT 
        u.userid AS professorId,
        CONCAT(u.firstname, ' ', u.lastname) AS professorName,
        c.course_name AS courseName,
        cl.class_id AS classId,
        cl.section AS section
    FROM users u 
    JOIN instructor_class ic ON u.userid = ic.instructor_id
    JOIN classes cl ON ic.class_id = cl.class_id
    JOIN courses c ON cl.course_id = c.course_id
    WHERE u.role = 'instructor'
";

$stmt = $pdo->prepare($query);
$stmt->execute();

$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

$professors = [];

foreach ($results as $row) {
    $professors[] = [
        'professorId' => $row['professorId'],
        'name' => $row['professorName'],
        'courseName' => $row['courseName'],
        'classId' => $row['classId'],
        'section' => $row['section']
    ];
}

// Output results
echo json_encode($professors);

?>
