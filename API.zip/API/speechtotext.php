<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
// Check if a file has been uploaded
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['audioFile']) && $_FILES['audioFile']['error'] == UPLOAD_ERR_OK) {
    // Your IBM Watson credentials
    $apiKey = 'li8YeiWZP36hyUYyH4DRLozJYtMGe0i2jmipiIH6z0Cc';
    $serviceUrl = 'https://api.us-south.speech-to-text.watson.cloud.ibm.com/instances/51d1e93c-d34f-4598-8d84-794a006262a6';

    // Retrieve the uploaded file
    $audioFilePath = $_FILES['audioFile']['tmp_name'];

    // cURL setup
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $serviceUrl . '/v1/recognize');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);

    // Open the audio file
    $audioFile = fopen($audioFilePath, 'rb');
    $audioData = fread($audioFile, filesize($audioFilePath));

    // Attach the audio data to the request
    curl_setopt($ch, CURLOPT_POSTFIELDS, $audioData);

    // Set the headers for the request
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: audio/wav',
        'Authorization: Basic ' . base64_encode('apikey:' . $apiKey),
    ));

    // Execute the request
    $result = curl_exec($ch);

    // Check for errors
    if (curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
    } else {
        // Success, handle the response
        echo $result;
    }

    // Close the audio file and cURL session
    fclose($audioFile);
    curl_close($ch);

} else {
    echo "An error occurred with file upload.";
}

?>
