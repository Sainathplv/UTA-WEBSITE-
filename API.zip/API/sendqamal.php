<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include __DIR__. '/mailer.php';

// Database Configuration
$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

$data = json_decode(file_get_contents("php://input"), true);

if (isset($data['to']) && isset($data['subject']) && isset($data['message'])) {
    $to = $data['to'];
    $subject = $data['subject'];
    $message = $data['message'];

    // Use mailer function from mailer.php
    $isSent = sendGenericMail($to, $subject, $message); 

    if ($isSent) {
        echo json_encode(['success' => true, 'message' => 'Mail sent successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to send mail']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Required data missing']);
}
?>
