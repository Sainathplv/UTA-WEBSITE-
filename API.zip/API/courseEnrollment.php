<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET,POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

// Fetch all courses
$query = "SELECT course_id, course_name FROM courses";
$stmt = $pdo->prepare($query);
$stmt->execute();
$courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

$result = [];

foreach($courses as $course) {
    $courseId = $course['course_id'];
    
    // Fetch classes details for each course
    $classesQuery = "SELECT class_id, section FROM classes WHERE course_id = ?";
    $classesStmt = $pdo->prepare($classesQuery);
    $classesStmt->execute([$courseId]);
    $classes = $classesStmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach($classes as &$class) {
        $classId = $class['class_id'];
        
        // Fetch count of students enrolled in each class
        $studentsCountQuery = "SELECT COUNT(*) as student_count FROM student_enrollment WHERE class_id = ?";
        $studentsCountStmt = $pdo->prepare($studentsCountQuery);
        $studentsCountStmt->execute([$classId]);
        $studentsCount = $studentsCountStmt->fetchColumn();
        
        $class['students_joined'] = $studentsCount;
    }
    
    $result[] = [
        'course_name' => $course['course_name'],
        'classes' => $classes
    ];
}

echo json_encode($result);
?>
