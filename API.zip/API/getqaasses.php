<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

try {
    $classID = $_GET['classID'];

    $stmt = $pdo->prepare(
        "SELECT c.course_name, u.lastname as instructor_name, cl.class_id 
        FROM classes cl 
        JOIN courses c ON cl.course_id = c.course_id 
        JOIN instructor_class ic ON cl.class_id = ic.class_id 
        JOIN instructors i ON ic.instructor_id = i.instructor_id 
        JOIN users u ON i.instructor_id = u.userid 
        WHERE cl.class_id = ?"
    );

    $stmt->execute([$classID]);

    $courseDetails = $stmt->fetch(PDO::FETCH_ASSOC);
    echo json_encode(['success' => true, 'courseDetails' => $courseDetails]);

} catch(Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Failed to fetch course details.']);
}
?>
