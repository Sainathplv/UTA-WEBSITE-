<?php
// Enable CORS for requests from the frontend domain
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Dialogflow integration
require_once __DIR__ . '/vendor/autoload.php';

use Google\Cloud\Dialogflow\V2\SessionsClient;
use Google\Cloud\Dialogflow\V2\TextInput;
use Google\Cloud\Dialogflow\V2\QueryInput;

// Replace with your Dialogflow project ID
$projectId = 'chatbot-405923';
$languageCode = 'en-US';

// Session ID should be unique for each user
$sessionId = uniqid('', true);

// Path to your service account credentials
putenv('GOOGLE_APPLICATION_CREDENTIALS=/API/chatbot-405923-294850ae55d8.json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $content = trim(file_get_contents("php://input"));
    $decoded = json_decode($content, true);

    $userMessage = $decoded['message'] ?? '';

    // Create new session
    $sessionClient = new SessionsClient();
    $session = $sessionClient->sessionName($projectId, $sessionId);

    // Create text input
    $textInput = new TextInput();
    $textInput->setText($userMessage);
    $textInput->setLanguageCode($languageCode);

    // Create query input
    $queryInput = new QueryInput();
    $queryInput->setText($textInput);

    // Get response and detect intent
    try {
        $response = $sessionClient->detectIntent($session, $queryInput);
        $queryResult = $response->getQueryResult();
        $fulfillmentText = $queryResult->getFulfillmentText();

        echo json_encode(['reply' => $fulfillmentText]);
    } catch (Exception $e) {
        echo json_encode(['reply' => 'I am sorry, an error occurred: ' . $e->getMessage()]);
    } finally {
        $sessionClient->close();
    }
}
?>
