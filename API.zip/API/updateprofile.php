<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

$input = json_decode(file_get_contents('php://input'), true);
$role = $_GET['role'];

try {
    $pdo->beginTransaction();

    $userQuery = "UPDATE users SET firstname = ?, lastname = ?, mailid = ?, dob = ?, password = ? WHERE userid = ?";
    $userStmt = $pdo->prepare($userQuery);
    $userStmt->execute([
        $input['firstname'], 
        $input['lastname'], 
        $input['mailid'], 
        $input['dob'], 
        $input['password'], 
        $input['userid']
    ]);

    switch ($role) {
        case 'student':
            $studentQuery = "UPDATE students SET enrollmentYear = ?, enrollmentSeason = ? WHERE user_id = ?";
            $studentStmt = $pdo->prepare($studentQuery);
            $studentStmt->execute([$input['enrollmentYear'], $input['enrollmentSeason'], $input['userid']]);
            break;

        case 'qaofficer':
            $qaofficerQuery = "UPDATE qa_officers SET start_date = ?, salary = ? WHERE qaofficer_id = ?";
            $qaofficerStmt = $pdo->prepare($qaofficerQuery);
            $qaofficerStmt->execute([$input['start_date'], $input['salary'], $input['userid']]);
            break;

        case 'instructor':
            $instructorQuery = "UPDATE instructors SET start_date = ? WHERE instructor_id = ?";
            $instructorStmt = $pdo->prepare($instructorQuery);
            $instructorStmt->execute([$input['start_date'], $input['userid']]);
            break;

        case 'program_coordinator':
            $coordinatorQuery = "UPDATE coordinators SET program = ?, start_date = ? WHERE user_id = ?";
            $coordinatorStmt = $pdo->prepare($coordinatorQuery);
            $coordinatorStmt->execute([$input['program'], $input['start_date'], $input['userid']]);
            break;

        case 'admin':
            $adminQuery = "UPDATE admins SET experience = ?, start_date = ? WHERE admin_id = ?";
            $adminStmt = $pdo->prepare($adminQuery);
            $adminStmt->execute([$input['experience'], $input['start_date'], $input['userid']]);
            break;

        default:
            echo json_encode(['status' => 'error', 'message' => 'Invalid role']);
            exit;
    }

    $pdo->commit();
    echo json_encode(['status' => 'success', 'message' => 'Profile updated successfully']);
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['status' => 'error', 'message' => 'Update failed: ' . $e->getMessage()]);
}
?>
