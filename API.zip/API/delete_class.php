// delete_class.php
<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

$data = json_decode(file_get_contents("php://input"));

if(isset($data->id)) {
    $stmt = $pdo->prepare("DELETE FROM classes WHERE class_id = ?");
    $result = $stmt->execute([$data->id]);

    if($result) {
        echo json_encode(['success' => true, 'message' => 'Class deleted successfully.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to delete class.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid input.']);
}
?>
