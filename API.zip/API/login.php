<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

$pdo = new PDO($dsn, $user, $pass);

$input = json_decode(file_get_contents('php://input'), true);

// Check for the provided email in the users table
$query = "SELECT userid, password, role FROM users WHERE mailid = ?";
$stmt = $pdo->prepare($query);
$stmt->execute([$input['username']]);
$userData = $stmt->fetch(PDO::FETCH_ASSOC);

// If user found and password matches
if ($userData && $input['password'] === $userData['password']) {
    unset($userData['password']); // Remove password from the result set
    echo json_encode([
        'status' => 'success',
        'data' => $userData,
        'message' => 'Login successful'
    ]);
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Incorrect username or password'
    ]);
}
?>
