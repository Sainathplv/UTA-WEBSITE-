<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

$stmt = $pdo->prepare("SELECT cm.id, cm.name, cm.email, cm.message 
FROM contact_messages cm
LEFT JOIN responses r ON cm.id = r.concern_id
WHERE r.concern_id IS NULL");
$stmt->execute();
$concerns = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode(['success' => true, 'concerns' => $concerns]);
?>
