<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_FILES['file']['tmp_name'])) {
        echo json_encode(['error' => 'No file uploaded.']);
        exit;
    }

    $filePath = $_FILES['file']['tmp_name'];
    $fileName = $_FILES['file']['name'];
    $url = 'https://api.ocr.space/parse/image';
    // Log details of the file
    error_log("File name: " . $_FILES['file']['name']);
    error_log("File type: " . $_FILES['file']['type']);
    error_log("File temp path: " . $_FILES['file']['tmp_name']);

    // Your OCR.space API key
    $apiKey = 'f55028e55188957';

    // Prepare the request with the correct fields as per OCR.space documentation
    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => [
            'apikey' => $apiKey,
            'file' => curl_file_create($filePath, mime_content_type($filePath), $fileName),
            'language' => 'eng',
            'isOverlayRequired' => 'true'
        ],
        CURLOPT_HTTPHEADER => [
            'Content-Type: multipart/form-data'
        ]
    ]);

    // Execute the request and handle errors
    $response = curl_exec($curl);
    if (curl_errno($curl)) {
        echo json_encode(['error' => curl_error($curl)]);
    } else {
        // Decode the response and return the parsed text or error message
        $decodedResponse = json_decode($response, true);
        if (isset($decodedResponse['ParsedResults'][0]['ParsedText'])) {
            echo json_encode(['text' => $decodedResponse['ParsedResults'][0]['ParsedText']]);
        } else {
            echo json_encode(['error' => 'OCR processing failed.', 'details' => $decodedResponse]);
        }
    }
    curl_close($curl);
} else {
    echo json_encode(['error' => 'Invalid request method.']);
}
?>
