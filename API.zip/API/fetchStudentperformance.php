<?php

// Headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Database Configuration
$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

$studentId = $_GET['studentId'];

// SQL query
$query = "
    SELECT 
        u.userid AS studentId,
        CONCAT(u.firstname, ' ', u.lastname) AS studentName,
        c.course_name AS courseName,
        ex.exam_name AS examName,
        eg.grade AS grade
    FROM users u
    LEFT JOIN student_enrollment se ON u.userid = se.user_id
    LEFT JOIN classes cl ON se.class_id = cl.class_id
    LEFT JOIN courses c ON cl.course_id = c.course_id
    LEFT JOIN instructor_class ic ON cl.class_id = ic.class_id
    LEFT JOIN Exams ex ON ic.class_id = ex.class_id
    LEFT JOIN student_exam_uploads seu ON (seu.student_id = u.userid AND seu.exam_id = ex.exam_id)
    LEFT JOIN exam_grades eg ON (eg.upload_id = seu.id AND eg.instructor_id = ic.instructor_id)
    WHERE u.userid = ? AND u.role = 'student'
";

$stmt = $pdo->prepare($query);
$stmt->execute([$studentId]);

$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

$students = [];

foreach ($results as $row) {
    if (!isset($students[$studentId])) {
        $students[$studentId] = [
            "studentId" => $studentId,
            "studentName" => $row["studentName"],
            "courses" => []
        ];
    }
    $students[$studentId]["courses"][] = [
        "courseName" => $row["courseName"],
        "exams" => [
            [
                "examName" => $row["examName"],
                "grade" => $row["grade"]
            ]
        ]
    ];
}

// Convert to a list
$studentsList = array_values($students);

// Output results
echo json_encode($studentsList);

?>
