<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: text/plain; charset=UTF-8');

// Database Configuration from your given code
$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

$name = $_POST['name'];
$email = $_POST['email'];
$subject = $_POST['subject'];
$message = $_POST['message'];

$query = "INSERT INTO contact_messages (name, email, subject, message) VALUES (?, ?, ?, ?)";
$stmt = $pdo->prepare($query);

try {
    $stmt->execute([$name, $email, $subject, $message]);
    echo "Thank you for contacting us. We'll get back to you shortly!";
} catch (PDOException $e) {
    http_response_code(500);
    echo "Error: " . $e->getMessage();
}
?>
