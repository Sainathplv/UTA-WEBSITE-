<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

$input = json_decode(file_get_contents('php://input'), true);
// Check if email already exists
$emailCheckQuery = "SELECT COUNT(*) FROM users WHERE mailid = ?";
$emailStmt = $pdo->prepare($emailCheckQuery);
$emailStmt->execute([$input['email']]);
$emailCount = $emailStmt->fetchColumn();

if ($emailCount > 0) {
    echo json_encode(['error' => 'Email already exists']);
    exit; // Stop further processing
}

try {
    // Insert data into the users table
    $query = "INSERT INTO users (firstname, lastname, mailid, password, dob, role) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$input['firstname'], $input['lastname'], $input['email'], $input['password'], $input['dob'], $input['role']]);
    
    // Get the last inserted user's ID
    $lastUserId = $pdo->lastInsertId();

    if ($input['role'] === 'instructor') {
        // Insert instructor start date into the instructors table
        $query = "INSERT INTO instructors (instructor_id, start_date) VALUES (?, ?)";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$lastUserId, $input['startDate']]);
    }

    echo json_encode(['message' => 'Registration successful']);
} catch (Exception $e) {
    echo json_encode(['error' => 'An error occurred. Please try again.']);
    error_log($e->getMessage());
}
?>
