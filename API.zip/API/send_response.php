<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include __DIR__. '/mailer.php';

// Database Configuration
$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);
// Fetching the incoming data
$input = json_decode(file_get_contents('php://input'), true);

if(isset($input['email']) && isset($input['message']) && isset($input['id']) && isset($input['coordinator_id']) && isset($input['datetime'])) {
    $datetime_mysql = date("Y-m-d H:i:s", strtotime($input['datetime']));
    $stmt = $pdo->prepare("INSERT INTO responses (concern_id, coordinator_id, response_message, datetime) VALUES (?, ?, ?, ?)");
    $result = $stmt->execute([$input['id'], $input['coordinator_id'], $input['message'], $datetime_mysql]);

    if ($result) {
        $emailResponse = sendResponseMail($input['email'], $input['message']);
        echo $emailResponse;
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to insert data into database.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Incomplete data received.']);
}
?>
