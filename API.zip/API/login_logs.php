<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

$pdo = new PDO($dsn, $user, $pass);

$input = json_decode(file_get_contents('php://input'), true);

if (isset($input['time'])) {
    $date = new DateTime($input['time']);
    $formattedDate = $date->format('Y-m-d H:i:s'); // Convert to MySQL datetime format
} else {
    echo json_encode(['error' => 'Time not provided']);
    exit();
}


if(isset($input['userId']) && isset($input['role']) && isset($input['time'])) {
    try {
        // Insert log details into the login_logs table
        $query = "INSERT INTO login_logs (userId, role, time) VALUES (?, ?, ?)";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$input['userId'], $input['role'], $formattedDate]);
        
        echo json_encode(['message' => 'Log recorded successfully']);
    } catch (Exception $e) {
        // Handle error - only show generic error messages to the user and log the actual error
        echo json_encode(['error' => 'Failed to record log']);
        error_log($e->getMessage());
    }
} else {
    echo json_encode(['error' => 'Incomplete data']);
}
?>
