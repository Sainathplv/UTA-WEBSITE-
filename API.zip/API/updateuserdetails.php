<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: PUT");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

$data = json_decode(file_get_contents("php://input"));

if(isset($data->userid) && isset($data->firstname) && isset($data->lastname) && isset($data->mailid)) {
    $query = "UPDATE users SET firstname = :firstname, lastname = :lastname, mailid = :mailid WHERE userid = :userid";
    
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':firstname', $data->firstname);
    $stmt->bindParam(':lastname', $data->lastname);
    $stmt->bindParam(':mailid', $data->mailid);
    $stmt->bindParam(':userid', $data->userid);

    if($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'User updated successfully']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to update user']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Missing data']);
}
?>
