<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

$data = json_decode(file_get_contents("php://input"));

if(isset($data->Program_code) && isset($data->course_name) && isset($data->course_id)) {
    $stmt = $pdo->prepare("INSERT INTO courses (Program_code, course_name, course_id) VALUES (?, ?, ?)");
    $result = $stmt->execute([$data->Program_code, $data->course_name, $data->course_id]);

    if($result) {
        // Check if fields for classes are set, and if so, insert into the classes table
        if(isset($data->location) && isset($data->section) && isset($data->total_seats)) {
            
            // Check if class with same section already exists
            $stmtCheck = $pdo->prepare("SELECT * FROM classes WHERE course_id = ? AND section = ?");
            $stmtCheck->execute([$data->course_id, $data->section]);
            $existingClass = $stmtCheck->fetch(PDO::FETCH_ASSOC);
            
            if ($existingClass) {
                echo json_encode(['success' => false, 'message' => 'Class with this section already exists.']);
            } else {
                $stmtClass = $pdo->prepare("INSERT INTO classes (course_id, location, section, total_seats) VALUES (?, ?, ?, ?)");
                $resultClass = $stmtClass->execute([$data->course_id, $data->location, $data->section, $data->total_seats]);
                
                if($resultClass) {
                    echo json_encode(['success' => true, 'message' => 'Class added successfully.']);
                } else {
                    echo json_encode(['success' => false, 'message' => 'Failed to add class.']);
                }
            }
        } else {
            echo json_encode(['success' => true, 'message' => 'Course added successfully.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to add course.']);
    }
}    
?>
