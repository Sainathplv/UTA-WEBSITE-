<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$studentId = $_GET['studentId'] ?? '';
$response = [];

if ($studentId) {
    // Fetch student basic details
    $stmt = $pdo->prepare("
        SELECT 
            u.userid,
            CONCAT(u.firstname, ' ', u.lastname) AS name,
            u.mailid as email
        FROM students s
        JOIN users u ON s.user_id = u.userid
        WHERE s.user_id = :id
    ");
    $stmt->bindParam(':id', $studentId);
    $stmt->execute();

    $response = $stmt->fetch(PDO::FETCH_ASSOC);

    // Fetch classes enrolled by the student and their associated courses
    $coursesStmt = $pdo->prepare("
        SELECT 
            c.course_id,
            c.course_name,
            se.class_id
        FROM student_enrollment se
        JOIN classes cl ON se.class_id = cl.class_id
        JOIN courses c ON cl.course_id = c.course_id
        WHERE se.user_id = :studentId
    ");
    $coursesStmt->bindParam(':studentId', $studentId);
    $coursesStmt->execute();

    $response['courses'] = $coursesStmt->fetchAll(PDO::FETCH_ASSOC);

    // For each course, fetch the exams, student's uploads and grades
    foreach ($response['courses'] as &$course) {
        $examStmt = $pdo->prepare("
            SELECT 
                e.exam_name,
                e.exam_id,
                su.file_url AS student_upload,
                eg.grade
            FROM Exams e
            LEFT JOIN student_exam_uploads su ON e.exam_id = su.exam_id AND su.student_id = :studentId
            LEFT JOIN exam_grades eg ON su.id = eg.upload_id
            WHERE e.class_id = :classId
        ");
        $examStmt->bindParam(':studentId', $studentId);
        $examStmt->bindParam(':classId', $course['class_id']);
        $examStmt->execute();
        $course['exams'] = $examStmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

echo json_encode($response);
?>
