<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

$pdo = new PDO($dsn, $user, $pass);

$input = json_decode(file_get_contents('php://input'), true);


$userId = $_GET['userId'];
$year = $_GET['year'];
$semester = $_GET['semester'];

try {
    $query = "SELECT c.*, co.* FROM instructor_class ic JOIN classes c ON ic.class_id = c.class_id JOIN courses co ON c.course_id = co.course_id WHERE ic.instructor_id = ? AND ic.academic_year = ? AND ic.season = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$userId, $year, $semester]);
    $classes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['status' => 'success', 'classes' => $classes]);
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => 'Database Error: ' . $e->getMessage()]);
}
?>
