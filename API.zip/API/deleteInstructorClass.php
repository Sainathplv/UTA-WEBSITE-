<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Database connection parameters
$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

// Get the input data from the request
$data = json_decode(file_get_contents("php://input"));

if(isset($data->classId) && isset($data->instructorId)) {
    $classId = $data->classId;
    $instructorId = $data->instructorId;
    
    // Prepare a statement to mark the specified class for the instructor as deleted
    $query = "UPDATE instructor_class SET is_deleted = 1 WHERE class_id = :classId AND instructor_id = :instructorId";
    $stmt = $pdo->prepare($query);

    // Execute the update
    if($stmt->execute([':classId' => $classId, ':instructorId' => $instructorId])) {
        if($stmt->rowCount()) {
            echo json_encode(['status' => 'success', 'message' => 'Class successfully marked as deleted.']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Class not found or already marked as deleted.']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Error executing the update operation.']);
    }

} else {
    echo json_encode(['status' => 'error', 'message' => 'Missing necessary data.']);
}
?>
