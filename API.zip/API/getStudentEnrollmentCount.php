<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

$studentID = $_GET['studentID'];

$sql = "SELECT COUNT(*) as count FROM student_enrollment WHERE user_id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$studentID]);

echo json_encode($stmt->fetch(PDO::FETCH_ASSOC)['count']);
?>
