<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Database credentials
// TODO: Move to a separate configuration or environment file
$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

// Query to fetch all admin emails
$query = "SELECT u.mailid AS email 
          FROM admins a 
          INNER JOIN users u ON a.admin_id = u.userid";
          
$stmt = $pdo->prepare($query);

try {
    $stmt->execute();
    $allEmails = $stmt->fetchAll(PDO::FETCH_COLUMN, 0);

    echo json_encode(['emails' => $allEmails]);
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => 'Database Error: ' . $e->getMessage()]);
}
?>
