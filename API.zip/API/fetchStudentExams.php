<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET,POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

$studentId = isset($_GET['studentId']) ? $_GET['studentId'] : die(json_encode(['success' => false, 'message' => 'Student ID is not provided']));

$query = "SELECT 
            e.exam_id, e.exam_name, e.exam_date, e.exam_file_url, e.max_marks, 
            c.course_name, cl.location, cl.section 
          FROM Exams e
          INNER JOIN classes cl ON e.class_id = cl.class_id
          INNER JOIN courses c ON cl.course_id = c.course_id
          INNER JOIN student_enrollment se ON se.class_id = cl.class_id
          WHERE se.user_id = ? AND e.exam_id NOT IN (SELECT exam_id FROM student_exam_uploads WHERE student_id = ?)";

$stmt = $pdo->prepare($query);
$stmt->execute([$studentId, $studentId]);

$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($results) {
    echo json_encode(['success' => true, 'data' => $results]);
} else {
    echo json_encode(['success' => false, 'message' => 'No exams found for the student']);
}
