<?php
require 'PHPMailer/PHPMailer/src/Exception.php';
require 'PHPMailer/PHPMailer/src/PHPMailer.php';
require 'PHPMailer/PHPMailer/src/SMTP.php';
use PHPMailer\PHPMailer\PHPMailer;





function sendWelcomeMail($username,$email_id){
    $phpmailer = new PHPMailer();
$phpmailer->isSMTP();
$phpmailer->Host = 'smtp-relay.brevo.com';
$phpmailer->SMTPAuth = true;
$phpmailer->SMTPSecure ='tls';
$phpmailer->Port = 587;
$phpmailer->Username = 'utamscs1@gmail.com'; 
$phpmailer->Password = 'IPFrWJ0d7YgB4cKz';

$phpmailer->isSMTP();
$phpmailer->setFrom('utamscs1@gmail.com','Admin UTAMSCS');
    $phpmailer->addAddress($email_id);
    $phpmailer->isHTML(true);
    $phpmailer->addReplyTo('utamscs1@gmail.com');
    $phpmailer->Subject='Welcome to UTA Masters in Computer Science!';
    $phpmailer->Body="Hello ".$username.",<br><br> Welcome to UTA Masters in Computer Science!!!<br><br> We strive to do our best provide you best service we have.<br>Here is your username: ".$email_id."
                       <br><br>Regards,<br>Admin";

    if($phpmailer->send())
    {
    return "email sent out successfully";
    }
    else
    {
        return "email sent out successfully". $phpmailer->ErrorInfo;
    }

    }

function forgotPassword($username,$email_id,$password)
{
    $phpmailer = new PHPMailer();
    $phpmailer->isSMTP();
    $phpmailer->Host = 'smtp-relay.brevo.com';
    $phpmailer->SMTPAuth = true;
    $phpmailer->SMTPSecure ='tls';
    $phpmailer->Port = 587;
    $phpmailer->Username = 'utamscs1@gmail.com'; 
    $phpmailer->Password = 'IPFrWJ0d7YgB4cKz';
    
    $phpmailer->isSMTP();
    $phpmailer->setFrom('utamscs1@gmail.com','Admin UTAMSCS');
        $phpmailer->addAddress($email_id);
        $phpmailer->isHTML(true);
         $phpmailer->addReplyTo('utamscs1@gmail.com');
        $phpmailer->Subject='Forgot Password';
        $phpmailer->Body="Hello ".$username.",<br><br> your password is: '$password',<br> please change your password as it is shared through email.<br><br>Regards,<br>Admin UTA-MSCS";
    
        if($phpmailer->send())
        {
            return json_encode(array("response"=>"success","message"=>"email sent out successfully"));
        }
        else
        {
            return json_encode(array("response"=>"failure","email sent out successfully". $phpmailer->ErrorInfo));
        } 
}

function sendResponseMail($email_id, $message){
    $phpmailer = new PHPMailer();
    $phpmailer->isSMTP();
    $phpmailer->Host = 'smtp-relay.brevo.com';
    $phpmailer->SMTPAuth = true;
    $phpmailer->SMTPSecure ='tls';
    $phpmailer->Port = 587;
    $phpmailer->Username = 'utamscs1@gmail.com'; 
    $phpmailer->Password = 'IPFrWJ0d7YgB4cKz';

    $phpmailer->setFrom('utamscs1@gmail.com','Admin UTAMSCS');
    $phpmailer->addAddress($email_id);
    $phpmailer->isHTML(true);
    $phpmailer->addReplyTo('utamscs1@gmail.com');
    $phpmailer->Subject='Response to Your Concern';
    $phpmailer->Body="Hello,<br><br>" . $message . "<br><br>Regards,<br>Admin";

    if($phpmailer->send()) {
        return json_encode(['success' => true, 'message' => 'Email sent successfully.']);
    } else {
        return json_encode(['success' => false, 'message' => 'Failed to send email.']);
    }
}

function sendGenericMail($to, $subject, $message){
    $phpmailer = new PHPMailer();
    $phpmailer->isSMTP();
    $phpmailer->Host = 'smtp-relay.brevo.com';
    $phpmailer->SMTPAuth = true;
    $phpmailer->SMTPSecure ='tls';
    $phpmailer->Port = 587;
    $phpmailer->Username = 'utamscs1@gmail.com'; 
    $phpmailer->Password = 'IPFrWJ0d7YgB4cKz';

    $phpmailer->setFrom('utamscs1@gmail.com','Admin UTAMSCS');
    $phpmailer->addAddress($to);
    $phpmailer->isHTML(true);
    $phpmailer->addReplyTo('utamscs1@gmail.com');
    $phpmailer->Subject = $subject;
    $phpmailer->Body = $message;

    if($phpmailer->send()) {
        return true;
    } else {
        return false;
    }
}





?>