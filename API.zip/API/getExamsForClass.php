<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

try {
    $classID = $_GET['classID'];

    $stmt = $pdo->prepare(
        "SELECT e.exam_name, e.exam_date, e.max_marks, e.exam_file_url, u.firstname as instructor_name 
        FROM Exams e 
        JOIN instructors i ON e.instructor_id = i.instructor_id 
        JOIN users u ON i.instructor_id = u.userid 
        WHERE e.class_id = ?"
    );

    $stmt->execute([$classID]);

    $exams = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['success' => true, 'exams' => $exams]);

} catch(Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Failed to fetch exams for the class.']);
}
?>
