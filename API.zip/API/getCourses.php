<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

$userId = $_GET['userId'];
$year = $_GET["year"];
$semester = $_GET["semester"];

$sql = "SELECT c.*, co.course_name, CONCAT(u.firstname, ' ', u.lastname) AS instructor_name, ic.academic_year, ic.season, ic.syllabus_link
        FROM classes c 
        INNER JOIN courses co ON c.course_id = co.course_id
        INNER JOIN instructor_class ic ON c.class_id = ic.class_id
        INNER JOIN users u ON ic.instructor_id = u.userid
        WHERE ic.academic_year = ? AND ic.season = ? AND u.role = 'instructor' AND ic.is_deleted = 0";

$stmt = $pdo->prepare($sql);
$stmt->execute([$year, $semester]);
$courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode(['courses' => $courses]);
?>
