<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

try {
    $stmt = $pdo->prepare("SELECT l.id, CONCAT(u.firstname, ' ', u.lastname) as name, l.role, l.time as date FROM login_logs l JOIN users u ON l.userId = u.userid");
    $stmt->execute();
    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $activityData = [];
    foreach($logs as $log) {
        $activity = array(
            "id" => $log['id'],
            "name" => $log['name'],
            "activity" => 'Logged in as ' . $log['role'],
            "date" => $log['date']
        );
        $activityData[] = $activity;
    }

    echo json_encode(['success' => true, 'activityData' => $activityData]);
} catch(Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Failed to fetch activity logs.']);
}
?>
