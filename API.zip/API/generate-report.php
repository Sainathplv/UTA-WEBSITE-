<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: text/csv; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

$table = $_GET['table'] ?? 'students';
$allowedTables = ["students", "instructors", "admins", "courses"];
if (!in_array($table, $allowedTables)) {
    die("Invalid table selected");
}

$columns = $_GET['columns'] ?? '*';
$startDate = $_GET['startDate'] ?? '';
$endDate = $_GET['endDate'] ?? '';
$page = $_GET['page'] ?? 1;
$limit = $_GET['limit'] ?? 50;
$offset = ($page - 1) * $limit;

$whereClause = "";
if ($startDate && $endDate && in_array("start_date", explode(',', $columns))) {
    $whereClause = "WHERE start_date BETWEEN ? AND ?";
}

$query = "SELECT $columns FROM $table $whereClause LIMIT $offset, $limit";

try {
    $stmt = $pdo->prepare($query);
    
    if ($whereClause) {
        $stmt->execute([$startDate, $endDate]);
    } else {
        $stmt->execute();
    }
    
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Prepare CSV data
    $csvData = "";

    // Fetch column headers only if $columns is not "*"
    if ($columns !== "*") {
        $csvData .= $columns . "\n";
    } else {
        $headers = array_keys(reset($records));
        $csvData .= implode(",", $headers) . "\n";
    }

    // Fetch rows
    foreach ($records as $record) {
        $csvData .= implode(",", $record) . "\n";
    }

    header("Content-Disposition: attachment; filename=\"$table-report.csv\"");

    echo $csvData;

} catch(Exception $e) {
    echo "Failed to generate report.";
}
?>
