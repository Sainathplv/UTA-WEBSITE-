<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET,POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

$role = $_GET['role'];

switch ($role) {
    case 'student':
        $query = "SELECT u.*, s.enrollmentYear, s.enrollmentSeason FROM users u JOIN students s ON u.userid = s.user_id";
        break;
    case 'qaofficer':
        $query = "SELECT u.*, q.start_date, q.salary FROM users u JOIN qa_officers q ON u.userid = q.qaofficer_id";
        break;

    case 'instructor':
        $query = "SELECT u.*, i.start_date FROM users u JOIN instructors i ON u.userid = i.instructor_id";
        break;

    case 'program_coordinator':
        $query = "SELECT u.*, c.start_date, c.program FROM users u JOIN coordinators c ON u.userid = c.user_id";
        break;

    case 'admin':
        $query = "SELECT u.*, a.start_date, a.experience FROM users u JOIN admins a ON u.userid = a.admin_id";
        break;
    default:
        echo json_encode(['status' => 'error', 'message' => 'Invalid role']);
        exit;
}

$stmt = $pdo->prepare($query);
$stmt->execute();
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($data) {
    echo json_encode(['status' => 'success', 'data' => $data]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'No users found for the given role']);
}
?>
