<?php
// Headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Database Configuration
$host = '51.81.160.154';
$db = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

$studentId = $_GET['studentId'];
$instructorId = $_SESSION['instructorId'] ?? $_GET['instructorId'];

$query = "
    SELECT c.course_name, e.exam_name, e.exam_date, e.max_marks, eg.grade, eg.feedback, eu.file_url
    FROM student_exam_uploads AS eu
    JOIN Exams AS e ON e.exam_id = eu.exam_id
    JOIN classes AS cl ON cl.class_id = e.class_id
    JOIN courses AS c ON c.course_id = cl.course_id
    LEFT JOIN exam_grades AS eg ON eg.upload_id = eu.id
    WHERE eu.student_id = ? AND e.instructor_id = ?
    ORDER BY c.course_name
";

$stmt = $pdo->prepare($query);
$stmt->execute([$studentId, $instructorId]);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Group data by courses
$data = [];
foreach ($results as $row) {
    $courseName = $row['course_name'];
    unset($row['course_name']); // Remove course_name from the inner data

    if (!isset($data[$courseName])) {
        $data[$courseName] = [];
    }
    $data[$courseName][] = $row;
}

if ($results) {
    echo json_encode(['success' => true, 'data' => $data]);
} else {
    echo json_encode(['success' => false, 'message' => 'No data found for the provided student ID and instructor ID.']);
}
?>