<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET,POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

$userId = $_GET['userId'];

// Determine the current semester based on the date
$date = new DateTime();
$month = (int) $date->format('m');
$day = (int) $date->format('d');

$semester = "Fall";
if ($month >= 1 && $month <= 5) {
    $semester = "Spring";
} elseif ($month == 6 || ($month == 8 && $day <= 15) || $month == 7) {
    $semester = "Summer";
}

// Fetch courses enrolled by the student for the determined semester
$query = "SELECT c.course_id,c.course_name,cl.section, s.class_id, s.academic_year, s.semester,cl.location,ic.syllabus_link  FROM student_enrollment s 
          JOIN classes cl ON s.class_id = cl.class_id 
          JOIN courses c ON cl.course_id = c.course_id 
          JOIN instructor_class ic ON ic.class_id = s.class_id
          WHERE s.user_id = ? AND s.semester = ?";

$stmt = $pdo->prepare($query);
$stmt->execute([$userId, $semester]);
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($data) {
    echo json_encode(['status' => 'success', 'data' => $data]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'No courses found for the student for the current semester']);
}
?>
