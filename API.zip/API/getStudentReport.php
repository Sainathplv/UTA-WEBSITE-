<?php
// Headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Database Configuration
$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

$userId = $_GET['userId'];

// SQL query
$query = "
SELECT
    c.course_id, 
    co.course_name,
    c.class_id,
    SUM(eg.grade) as total_grade_for_course,
    e.exam_id,
    e.exam_name,
    e.max_marks,
    eg.grade,
    (SELECT SUM(eg2.grade) / COUNT(eg2.grade_id) 
     FROM exam_grades eg2
     JOIN student_exam_uploads seu2 ON eg2.upload_id = seu2.id 
     WHERE seu2.exam_id = e.exam_id) as mean_grade
FROM student_enrollment se
JOIN classes c ON se.class_id = c.class_id
JOIN courses co ON c.course_id = co.course_id
JOIN Exams e ON c.class_id = e.class_id
LEFT JOIN student_exam_uploads seu ON seu.exam_id = e.exam_id AND seu.student_id = ?
LEFT JOIN exam_grades eg ON seu.id = eg.upload_id
WHERE se.user_id = ?
GROUP BY c.course_id, co.course_name, c.class_id, e.exam_id, e.exam_name, e.max_marks, eg.grade
";

$stmt = $pdo->prepare($query);
$stmt->execute([$userId, $userId]);

$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

$groupedCourses = [];
foreach ($results as $row) {
    if (!isset($groupedCourses[$row['course_id']])) {
        $groupedCourses[$row['course_id']] = [
            'courseId' => $row['course_id'],
            'courseName' => $row['course_name'],
            'classid' => $row['class_id'],
            'exams' => []
        ];
    }
    
    $exam = [
        'examId' => $row['exam_id'],
        'examName' => $row['exam_name'],
        'maxMarks' => $row['max_marks'],
        'grade' => $row['grade'],
        'meanGrade' => $row['mean_grade']
    ];
    $groupedCourses[$row['course_id']]['exams'][] = $exam;
}

// Convert to a list
$coursesList = array_values($groupedCourses);

// Output results
echo json_encode($coursesList);
