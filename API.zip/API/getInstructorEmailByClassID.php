<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Database credentials
// TODO: Move to a separate configuration or environment file
$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

if (isset($_GET['classID'])) {
    $classID = $_GET['classID'];

    // Query to fetch the instructor's email based on classID
    $query = "SELECT u.mailid AS email 
              FROM instructors i 
              INNER JOIN users u ON i.instructor_id = u.userid 
              INNER JOIN instructor_class ic ON i.instructor_id = ic.instructor_id 
              WHERE ic.class_id = ?";

    $stmt = $pdo->prepare($query);

    try {
        $stmt->execute([$classID]);
        $emailData = $stmt->fetch(PDO::FETCH_ASSOC);

        echo json_encode(['email' => $emailData['email']]);
    } catch (PDOException $e) {
        echo json_encode(['status' => 'error', 'message' => 'Database Error: ' . $e->getMessage()]);
    }
}
?>

