<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

$userId = isset($_GET['userId']) ? $_GET['userId'] : die(json_encode(['success' => false, 'message' => 'User ID not provided.']));

try {
    $stmt = $pdo->prepare("SELECT lastname FROM users WHERE userid = ?");
    $stmt->execute([$userId]);
    
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if($user) {
        echo json_encode(['success' => true, 'lastname' => $user['lastname']]);
    } else {
        echo json_encode(['success' => false, 'message' => 'No user found with the provided userId.']);
    }
} catch(Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Failed to fetch user data.']);
}
?>
