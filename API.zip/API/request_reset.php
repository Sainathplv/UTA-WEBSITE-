<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Database connection details
$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

$pdo = new PDO($dsn, $user, $pass);

$input = json_decode(file_get_contents('php://input'), true);

// Checking if the email is set
if(isset($input['mailid'])) {
    $email = $input['mailid'];
    
    // Fetch user details using the email provided
    $stmt = $pdo->prepare("SELECT lastname, mailid, password FROM users WHERE mailid = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if($user) {
        // If user exists, send the reset password email
        include __DIR__. '/mailer.php';
        $response = json_decode(forgotPassword($user["lastname"], $user["mailid"], $user["password"]), true);
        if ($response["response"] == "success") {
            echo json_encode(['success' => true, 'message' => ' successfully sent,Please check your email for password reset instructions.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to send email.']);
        }
    } else {
        // If user does not exist, send an error message
        echo json_encode(['success' => false, 'message' => 'Invalid email address']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Email not provided']);
}
?>
