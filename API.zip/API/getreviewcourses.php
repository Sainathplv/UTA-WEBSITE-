<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

try {
    $stmt = $pdo->prepare("
    SELECT 
    c.course_id as id, 
    c.course_name as title, 
    cl.class_id,
    CONCAT(u.firstname, ' ', u.lastname) as professor,
    IFNULL(ic.syllabus_link, '') as syllabus,  
    cl.location as building
FROM courses c
JOIN classes cl ON cl.course_id = c.course_id
LEFT JOIN instructor_class ic ON cl.class_id = ic.class_id
LEFT JOIN users u ON u.userid = ic.instructor_id
WHERE COALESCE(ic.is_deleted, 0) = 0  
order by c.course_id  
    ");
    
    $stmt->execute();

    $resultData = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $coursesData = [];
    foreach ($resultData as $row) {
        if (is_null($row['id']) || is_null($row['title']) || is_null($row['class_id'])) {
            continue;
        }

        if (!isset($coursesData[$row['id']])) {
            $coursesData[$row['id']] = [
                'id' => $row['id'],
                'title' => $row['title'],
                'classes' => []
            ];
        }

        $coursesData[$row['id']]['classes'][] = [
            'class_id' => $row['class_id'],
            'professor' => $row['professor'],
            'syllabus' => $row['syllabus'],
            'building' => $row['building']
        ];
    }

    // Filter out any courses without classes
    $coursesData = array_filter($coursesData, function ($course) {
        return count($course['classes']) > 0;
    });

    if ($coursesData) {
        echo json_encode(['success' => true, 'courses' => array_values($coursesData)]);
    } else {
        echo json_encode(['success' => false, 'message' => 'No courses found.']);
    }

} catch(Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Failed to fetch courses.', 'error' => $e->getMessage()]);
}
?>
