<?php
// Headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Database Configuration
$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

// Receive and Decode JSON
$data = json_decode(file_get_contents("php://input"), true);

// SQL query
$query = "INSERT INTO exam_grades (upload_id, instructor_id, grade, feedback) VALUES (?, ?, ?, ?)";
$stmt = $pdo->prepare($query);
$result = $stmt->execute([
    $data['upload_id'], 
    $data['instructor_id'], 
    $data['grade'], 
    $data['feedback']
]);

// Output result
echo $result ? json_encode(['success' => true, 'message' => 'Grade and feedback stored successfully'])
             : json_encode(['success' => false, 'message' => 'Failed to store data']);
?>
