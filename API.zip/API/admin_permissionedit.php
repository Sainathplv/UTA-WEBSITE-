<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");


// Database connection parameters
$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

$userId = $_POST['user_id'] ?? null;
$newPermissions = $_POST['permissions'] ?? [];

if (!$userId || empty($newPermissions)) {
    echo json_encode(['success' => false, 'message' => 'User ID and permissions are required']);
    exit;
}

try {
    $pdo->beginTransaction();

    // Delete existing permissions
    $pdo->exec("DELETE FROM user_permissions WHERE user_id = $userId");

    // Add new permissions
    foreach ($newPermissions as $permissionName) {
        $stmt = $pdo->prepare("SELECT permission_id FROM permissions WHERE permission_name = ?");
        $stmt->execute([$permissionName]);
        $permission = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($permission) {
            $stmt = $pdo->prepare("INSERT INTO user_permissions (user_id, permission_id) VALUES (?, ?)");
            $stmt->execute([$userId, $permission['permission_id']]);
        } else {
            // Handle invalid permissions
            echo json_encode(['success' => false, 'message' => "Permission '$permissionName' not found"]);
            $pdo->rollBack();
            exit;
        }
    }

    $pdo->commit();
    echo json_encode(['success' => true, 'message' => 'Permissions updated successfully.']);

} catch (PDOException $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
