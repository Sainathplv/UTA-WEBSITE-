<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Database credentials
// TODO: Move to a separate configuration or environment file
$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

// Fetching POSTed JSON data
$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (!isset($data['instructorId']) || !isset($data['year']) || !isset($data['semester']) || !isset($data['selectedCourses'])) {
    echo json_encode(['status' => 'error', 'message' => 'Required data missing']);
    exit;
}

$userId = $data['instructorId'];
$year = $data['year'];
$semester = $data['semester'];
$courses = $data['selectedCourses'];

try {
    foreach ($courses as $courseId) {
        // Check if the instructor is already teaching 3 classes this semester
        $countQuery = "SELECT COUNT(*) as count FROM instructor_class WHERE instructor_id = ? AND academic_year = ? AND season = ? AND is_deleted = 0 " ;
        $countStmt = $pdo->prepare($countQuery);
        $countStmt->execute([$userId, $year, $semester]);
        $count = $countStmt->fetch(PDO::FETCH_ASSOC)["count"];
    
        if ($count >= 3) {
            echo json_encode(['status' => 'error', 'message' => 'Instructor is already teaching 3 classes this semester.']);
            exit;
        }
    
        $existingClassQuery = "SELECT section FROM classes WHERE class_id = ? ORDER BY section DESC LIMIT 1";
        $existingClassStmt = $pdo->prepare($existingClassQuery);
        $existingClassStmt->execute([$courseId]);
        $existingClass = $existingClassStmt->fetch(PDO::FETCH_ASSOC);
    
        // Determine the section to use for the new class
        $newSection = 'A'; // Default to 'A' if no existing class is found
        if ($existingClass) {
            $lastSection = $existingClass['section'];
            $nextChar = chr(ord($lastSection) + 1);
            if (in_array($nextChar, ['A', 'B', 'C', 'D'])) {
                $newSection = $nextChar;
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Cannot create another section beyond D.']);
                exit;
            }
        }
    
        $enrollQuery = "INSERT INTO classes (course_id,section,total_seats,leftover_seats) VALUES (?, ?, ?, ?)";
        $enrollStmt = $pdo->prepare($enrollQuery);
        $enrollStmt->execute([$courseId,$newSection,40,40]);

        // Get the last inserted class ID
        $lastClassId = $pdo->lastInsertId();

        // Now, insert the new class ID and instructor ID into the `instructor_class` table
        $instructorClassQuery = "INSERT INTO instructor_class (instructor_id, class_id, academic_year, season) VALUES (?, ?, ?, ?)";
        $instructorClassStmt = $pdo->prepare($instructorClassQuery);
        $instructorClassStmt->execute([$userId, $lastClassId, $year, $semester]);


    }
    
    
    echo json_encode(['status' => 'success', 'message' => 'Successfully enrolled to classes.']);
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => 'Database Error: ' . $e->getMessage()]);
}
?>
