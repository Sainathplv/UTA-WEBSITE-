<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

// Retrieve the data sent in the POST request
$data = json_decode(file_get_contents("php://input"));

if (isset($data->instructor_id) && isset($data->class_id) && isset($data->exam_name) && isset($data->exam_date) && isset($data->exam_file_url) && isset($data->max_marks)) {
    
    $stmt = $pdo->prepare("INSERT INTO Exams (instructor_id, class_id, exam_name, exam_date, exam_file_url, max_marks) VALUES (?, ?, ?, ?, ?, ?)");
    
    if ($stmt->execute([$data->instructor_id, $data->class_id, $data->exam_name, $data->exam_date, $data->exam_file_url, $data->max_marks])) {
        echo json_encode(['success' => true, 'message' => 'Exam successfully created!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'There was an error creating the exam. Please try again.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid input']);
}
?>
