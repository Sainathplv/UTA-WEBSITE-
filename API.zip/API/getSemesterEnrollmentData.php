<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Database connection parameters
$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);


try {
    $currentYear = date("Y");
    
    $stmt = $pdo->prepare("SELECT COUNT(*) as total, enrollmentSeason FROM students WHERE enrollmentYear = :year GROUP BY enrollmentSeason ORDER BY FIELD(enrollmentSeason, 'Spring', 'Summer', 'Fall')");
    $stmt->execute(['year' => $currentYear]);

    $enrollmentData = $stmt->fetchAll();
    $labels = array_column($enrollmentData, 'enrollmentSeason');
    $values = array_column($enrollmentData, 'total');

    echo json_encode(['success' => true, 'labels' => $labels, 'values' => $values]);

} catch (\PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Failed to connect to the database: ' . $e->getMessage()]);
}

?>
