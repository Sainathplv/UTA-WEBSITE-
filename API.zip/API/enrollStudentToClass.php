<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

$input = json_decode(file_get_contents('php://input'), true);

$studentID = $input['studentID'];
$classID = $input['classID'];
$coordinatorOverride = isset($input['coordinatorOverride']) ? $input['coordinatorOverride'] : false;

// Determine the current semester
$month = date('m');
$day = date('d');
$year = date('Y');

if ($month >= 1 && $month <= 5) {
    $semester = "Spring";
} elseif ($month == 6 || ($month == 8 && $day <= 15)) {
    $semester = "Summer";
} else {
    $semester = "Fall";
}

// Check if student is already enrolled in the class/course for the current semester
$sql = "SELECT COUNT(*) as count 
        FROM student_enrollment 
        WHERE user_id = ? 
        AND class_id = ? 
        AND semester = ? 
        AND academic_year = ?";

$stmt = $pdo->prepare($sql);
$stmt->execute([$studentID, $classID, $semester, $year]);
$count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

if ($count > 0) {
    echo json_encode([
        'status' => 'error',
        'message' => 'The student is already enrolled in this class for this semester.'
    ]);
    exit();
}

// Check total courses student is enrolled in for the current semester
$sql = "SELECT COUNT(*) as count 
        FROM student_enrollment 
        WHERE user_id = ? 
        AND semester = ? 
        AND academic_year = ?";

$stmt = $pdo->prepare($sql);
$stmt->execute([$studentID, $semester, $year]);
$count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

// A student can enroll in up to 3 courses by himself/herself. A coordinator can enroll the student in 1 additional course.
$maxCourses = $coordinatorOverride ? 4 : 3;

if ($count >= $maxCourses) {
    $message = $coordinatorOverride ? 
        'The student is already enrolled in 4 courses this semester.' :
        'The student can only enroll in up to 3 courses. Please contact a coordinator for further assistance.';

    echo json_encode([
        'status' => 'error',
        'message' => $message
    ]);
    exit();
}

// Enroll student in the class
$sql = "INSERT INTO student_enrollment (user_id, class_id, semester, academic_year) 
        VALUES (?, ?, ?, ?)";
$stmt = $pdo->prepare($sql);

if ($stmt->execute([$studentID, $classID, $semester, $year])) {
    echo json_encode([
        'status' => 'success',
        'message' => 'Student enrolled successfully.'
    ]);
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Error: ' . $stmt->errorInfo()[2]
    ]);
}
?>
