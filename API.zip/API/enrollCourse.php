<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Only for debugging. Remove in production.
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['userId']) || !isset($data["year"]) || !isset($data["semester"]) || !isset($data["class_id"])) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request data.']);
    exit();
}

$userId = $data['userId'];
$year = $data["year"];
$semester = $data["semester"];
$classId = $data["class_id"];

// Check if the student is already enrolled in the same class for this semester and academic year
$sql = "SELECT COUNT(*) as count
        FROM student_enrollment
        WHERE user_id = ? AND academic_year = ? AND semester = ? AND class_id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$userId, $year, $semester, $classId]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);
if ($row["count"] > 0) {
    echo json_encode(['status' => 'error', 'message' => 'You are already enrolled in this class for the specified semester.']);
    exit();
}

// Check if there are any seats left
$sql = "SELECT leftover_seats FROM classes WHERE class_id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$classId]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);
if ($row["leftover_seats"] <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'No seats available.']);
    exit();
}

// Check if the student is already enrolled in 3 courses for this semester and academic year
$sql = "SELECT COUNT(*) as count
        FROM student_enrollment
        WHERE user_id = ? AND academic_year = ? AND semester = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$userId, $year, $semester]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);
if ($row["count"] >= 3) {
    echo json_encode(['status' => 'error', 'message' => "You can't enroll in a 4th subject. Please contact the program coordinator."]);
    exit();
}

try {
    $pdo->beginTransaction();

    // Decrement available seats by 1
    $sql = "UPDATE classes SET leftover_seats = leftover_seats - 1 WHERE class_id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$classId]);

    // Enroll the student
    $sql = "INSERT INTO student_enrollment (user_id, class_id, academic_year, semester)
            VALUES (?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$userId, $classId, $year, $semester]);

    $pdo->commit();

    echo json_encode(['status' => 'success', 'message' => 'Successfully enrolled!']);
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['status' => 'error', 'message' => 'Failed to enroll. Reason: ' . $e->getMessage()]);
}

?>
