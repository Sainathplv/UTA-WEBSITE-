<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$host = '51.81.160.154';
$db   = 'plv9223_WDM';
$user = 'plv9223_wdm';
$pass = 'Palavala@3410';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$pdo = new PDO($dsn, $user, $pass);

$data = json_decode(file_get_contents("php://input"));

if(isset($data->instructor_id) && isset($data->class_id) && isset($data->syllabus_link)) {
    try {
        // Check if a record exists with the given instructor_id and class_id
        $stmt_check = $pdo->prepare("SELECT 1 FROM instructor_class WHERE instructor_id = ? AND class_id = ?");
        $stmt_check->execute([$data->instructor_id, $data->class_id]);

        if($stmt_check->fetchColumn()) {
            // If the record exists, update the syllabus_link
            $stmt = $pdo->prepare("UPDATE instructor_class SET syllabus_link = ? WHERE instructor_id = ? AND class_id = ?");
            $stmt->execute([$data->syllabus_link, $data->instructor_id, $data->class_id]);
        } else {
            // If no record exists, insert a new one
            $stmt = $pdo->prepare("INSERT INTO instructor_class (instructor_id, class_id, syllabus_link) VALUES (?, ?, ?)");
            $stmt->execute([$data->instructor_id, $data->class_id, $data->syllabus_link]);
        }

        echo json_encode(['success' => true, 'message' => 'Syllabus link successfully uploaded or updated.']);

    } catch(Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Failed to upload or update syllabus link.', 'error' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Incomplete data provided.']);
}
?>
